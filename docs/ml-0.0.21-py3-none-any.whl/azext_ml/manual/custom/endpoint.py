# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from argparse import ONE_OR_MORE
from typing import Dict, Any
from azure.ml import MLClient
from azure.identity import AzureCliCredential
from azure.cli.core.commands.client_factory import get_subscription_id
from azure.ml.constants import BATCH_ENDPOINT_TYPE, ONLINE_ENDPOINT_TYPE, EndpointGetLogsFields
from azure.ml._utils.utils import load_yaml
from .print_error import print_error_and_exit, print_warning


def ml_endpoint_show(cmd, resource_group_name, workspace_name, name, type=ONLINE_ENDPOINT_TYPE):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
    )
    try:
        return ml_client.endpoints.get(type=type, name=name)._deserialize()
    except Exception as err:
        print_error_and_exit(err)


def ml_endpoint_create(cmd, resource_group_name, workspace_name, file, name=None, type=None, wait=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    try:
        ml_client = MLClient(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            default_workspace_name=workspace_name,
            credential=AzureCliCredential(),
        )
        endpoint = ml_client.endpoints.create(type=type, name=name, file=file, wait=wait)
        if endpoint:
            # online endpoint will not return the endpoint object. So we have to add this check here.
            return endpoint._deserialize()
    except Exception as err:
        print_error_and_exit(err)


def ml_endpoint_delete(cmd, resource_group_name, workspace_name, name, deployment=None, type=ONLINE_ENDPOINT_TYPE):
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)

        ml_client = MLClient(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            default_workspace_name=workspace_name,
            credential=AzureCliCredential(),
        )
        return ml_client.endpoints.delete(type=type, name=name, deployment=deployment)
    except Exception as err:
        print_error_and_exit(err)


def ml_endpoint_get_deployment_logs(
    cmd,
    resource_group_name,
    workspace_name,
    name,
    deployment,
    tail=EndpointGetLogsFields.TAIL,
    type=ONLINE_ENDPOINT_TYPE,
    container=None,
):
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)
        ml_client = MLClient(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            default_workspace_name=workspace_name,
            credential=AzureCliCredential(),
        )
        logs = ml_client.endpoints.get_deployment_logs(
            type=type, endpoint_name=name, deployment_name=deployment, tail=tail, container_type=container
        )
        print(logs.replace("\\n", "\n"))
    except Exception as err:
        print_error_and_exit(err)


def ml_endpoint_listkeys(cmd, resource_group_name, workspace_name, name, type=ONLINE_ENDPOINT_TYPE):
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)

        ml_client = MLClient(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            default_workspace_name=workspace_name,
            credential=AzureCliCredential(),
        )
        return ml_client.endpoints.list_keys(type=type, name=name)
    except Exception as err:
        print_error_and_exit(err)


def ml_endpoint_list(cmd, resource_group_name, workspace_name, type=ONLINE_ENDPOINT_TYPE):
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)

        ml_client = MLClient(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            default_workspace_name=workspace_name,
            credential=AzureCliCredential(),
        )
        return ml_client.endpoints.list(type=type)
    except Exception as err:
        print_error_and_exit(err)


def ml_endpoint_update(
    cmd,
    resource_group_name,
    workspace_name,
    name=None,
    type=ONLINE_ENDPOINT_TYPE,
    deployment=None,
    traffic=None,
    instance_count=None,
    file=None,
    deployment_file=None,
    wait=False,
    **kwargs
) -> None:
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)

        ml_client = MLClient(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            default_workspace_name=workspace_name,
            credential=AzureCliCredential(),
        )
        endpoint = kwargs["parameters"]

        return ml_client.endpoints.update(
            type=type,
            name=name,
            endpoint=endpoint,
            deployment=deployment,
            traffic=traffic,
            instance_count=instance_count,
            file=file,
            deployment_file=deployment_file,
            wait=wait,
        )
    except Exception as err:
        print_error_and_exit(err)


def ml_endpoint_update_show(cmd, resource_group_name, workspace_name, file=None, name=None, type=ONLINE_ENDPOINT_TYPE):
    try:
        if file:
            cfg = load_yaml(file)
            name = name or cfg.get("name", None)
        if not name:
            raise Exception("A name must be passed through the CLI or be present in your yaml file")
        return ml_endpoint_show(cmd, resource_group_name, workspace_name, name, type=type)
    except Exception as err:
        print_error_and_exit(err)


def ml_endpoint_invoke(
    cmd,
    resource_group_name,
    workspace_name,
    name,
    request_file=None,
    input_data_name=None,
    input_data_version=None,
    input_path=None,
    deployment=None,
    type=ONLINE_ENDPOINT_TYPE,
) -> str:
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)
        ml_client = MLClient(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            default_workspace_name=workspace_name,
            credential=AzureCliCredential(),
        )
        return ml_client.endpoints.invoke(
            endpoint_name=name,
            type=type,
            request_file=request_file,
            input_data_name=input_data_name,
            input_data_version=input_data_version,
            input_path=input_path,
            deployment_name=deployment,
        )
    except Exception as err:
        print_error_and_exit(err)


def ml_endpoint_list_jobs(cmd, resource_group_name, workspace_name, name, deployment=None, type=BATCH_ENDPOINT_TYPE):
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)
        ml_client = MLClient(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            default_workspace_name=workspace_name,
            credential=AzureCliCredential(),
        )

        return ml_client.endpoints.list_jobs(endpoint_name=name, type=type, deployment_name=deployment)
    except Exception as err:
        print_error_and_exit(err)
