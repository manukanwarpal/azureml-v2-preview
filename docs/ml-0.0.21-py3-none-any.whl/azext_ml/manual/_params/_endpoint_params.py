# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._common_params import add_common_params


def load_endpoint_params(self):
    with self.argument_context("ml endpoint create") as c:
        add_common_params(c)
        c.argument("name", options_list=["--name", "-n"], type=str, help="endpoint name")
        c.argument("file", help="yaml file from which to generate online endpoint")
        c.argument("type", help="the type of the endpoint: online or batch. online is the default")
        c.argument(
            "wait",
            action="store_true",
            help="wait for the endpoint create to finish and stream the logs to the console. Default is no wait",
        )

    with self.argument_context("ml endpoint show") as c:
        add_common_params(c)
        c.argument("name", options_list=["--name", "-n"], type=str, help="endpoint name")
        c.argument("type", help="the type of the endpoint: online or batch. online is the default")

    with self.argument_context("ml endpoint delete") as c:
        add_common_params(c)
        c.argument("name", options_list=["--name", "-n"], type=str, help="endpoint name")
        c.argument("type", help="the type of the endpoint: online or batch. online is the default")
        c.argument("deployment", help="the deployment to be deleted")

    with self.argument_context("ml endpoint list-keys") as c:
        add_common_params(c)
        c.argument("name", options_list=["--name", "-n"], type=str, help="endpoint name")
        c.argument(
            "type", help="the type of the endpoint: only online endpoints support for listing keys at this point."
        )

    with self.argument_context("ml endpoint list") as c:
        add_common_params(c)
        c.argument("type", help="the type of the endpoint: online or batch. online is the default")

    with self.argument_context("ml endpoint log") as c:
        add_common_params(c)
        c.argument("type", help="the type of endpoint: online or batch")
        c.argument("name", options_list=["--name", "-n"], help="name of the endpoint")
        c.argument("deployment", help="name of the deployment")
        c.argument("tail", help="max number of lines to tail")
        c.argument(
            "container",
            help="type of container from which to retrieve logs: \
            inference-server or storage-initializer",
        )

    with self.argument_context("ml endpoint update") as c:
        add_common_params(c)
        c.argument("type", help="the type of endpoint: online or batch")
        c.argument("name", options_list=["--name", "-n"], help="name of the endpoint")
        c.argument("deployment", help="name of the deployment")
        c.argument("traffic", help="traffic settings")
        c.argument("instance_count", help="instance count")
        c.argument("file", help="yaml file to update endpoint")
        c.argument("deployment_file", help="yaml file to update deployment")
        c.argument(
            "wait",
            action="store_true",
            help="wait for the endpoint update to finish and stream the logs to the console. Default is no wait",
        )

    with self.argument_context("ml endpoint invoke") as c:
        add_common_params(c)
        c.argument("type", help="the type of endpoint: online or batch")
        c.argument("name", options_list=["--name", "-n"], help="name of the endpoint")
        c.argument("deployment", help="name of the deployment to target")
        c.argument("request_file", help="path to json file containing request data, for online endpoints only.")
        c.argument("input_data_name", help="Input data asset name, for batch endpoints only.")
        c.argument("input_data_version", help="Input data asset version, for batch endpoints only.")
        c.argument(
            "input_data_path",
            help="Local path of input data, the local path will be uploaded and registered as an Azure ML data asset, for batch endpoints only.",
        )

    with self.argument_context("ml endpoint list-jobs") as c:
        add_common_params(c)
        c.argument("type", help="The type of endpoint: only batch endpoints support listing jobs.")
        c.argument("name", options_list=["--name", "-n"], help="Name of the endpoint.")
        c.argument("deployment", help="Name of the deployment to target.")
