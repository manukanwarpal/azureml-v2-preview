# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_endpoint_help():
    helps[
        "ml endpoint"
    ] = """
        type: group
        short-summary: ml endpoint
    """
