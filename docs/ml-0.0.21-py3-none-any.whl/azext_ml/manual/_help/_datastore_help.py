# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_datastore_help():
    helps[
        "ml datastore"
    ] = """
        type: group
        short-summary: ml datastore
    """
    helps[
        "ml datastore list"
    ] = """
        type: command
        short-summary: "Lists all datastore attached to the workspace."
    """
    helps[
        "ml datastore show"
    ] = """
            type: command
            short-summary: "Get the specified datastore."
        """
    helps[
        "ml datastore create"
    ] = """
                type: command
                short-summary: "Attaches the specified datastore to the workspace"
            """

    helps[
        "ml datastore delete"
    ] = """
                type: command
                short-summary: "Deletes the reference to the specified datastore from the workspace"
    """
