# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_model_help():
    helps[
        "ml model"
    ] = """
        type: group
        short-summary: Commands to manage model.
    """

    helps[
        "ml model create"
    ] = """
        type: command
        short-summary: Register a model object either from a local file/folder or from an existing asset.
        examples:
        - name: Register a model from a local folder
          text: az ml model create --name my-model --version 1 --path path-to-folder
        - name: Register a model from a local yaml file
          text: az ml model create --file simplemodel.yml
    """

    helps[
        "ml model show"
    ] = """
        type: command
        short-summary: Shows the state of a model version in a yaml format.
        examples:
        - name: Show a model
          text: az ml model show --name my-model --version 1
    """

    helps[
        "ml model list"
    ] = """
        type: command
        short-summary: List the models in a workspace with a given name.
        examples:
        - name: List models with the same name
          text: az ml model list --name my-model
    """

    helps[
        "ml model update"
    ] = """
        type: command
        short-summary: Add, edit, and remove model version tags and asset tags.
        examples:
        - name: Update a model
          text: az ml model update --name my-model --version 1 --set flavors.python_function.python_version=3.8
    """
